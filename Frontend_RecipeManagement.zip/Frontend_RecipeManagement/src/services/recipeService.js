import axios from 'axios';

const API_BASE = 'https://localhost:5001/api/recipes';

// Configure axios instance
const apiClient = axios.create({
  baseURL: API_BASE,
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest'
  }
});


export const fetchRecipes = async () => {
  try {
    const response = await apiClient.get('/');
    return response.data.map(recipe => ({
      ...recipe,
      image: recipe.imagePath ? `http://localhost:5000/Images/${recipe.imagePath}` : null,
    }));
  } catch (error) {
    throw new Error('Failed to fetch recipes');
  }
};

export const createRecipe = async (recipeData) => {
  try {
    const formData = new FormData();
    Object.entries(recipeData).forEach(([key, value]) => {
      if (key === 'image' && value) {
        formData.append('image', value);
      } else {
        formData.append(key, value);
      }
    });

    const response = await apiClient.post('/', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to create recipe');
  }
};

export const saveRecipeAPI = async (recipeId) => {
  try {
    const response = await apiClient.post(`/${recipeId}/save`);
    return {
      ...response.data,
      image: response.data.imagePath ? 
        `http://localhost:5000/Images/${response.data.imagePath}` : null
    };
  } catch (error) {
    throw new Error('Failed to save recipe');
  }
};

export const deleteRecipeAPI = async (recipeId) => {
  try {
    const response = await apiClient.delete(`/${recipeId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to delete recipe');
  }
};



export const updateRecipeAPI = async (recipeData) => {
  try {
    const formData = new FormData();
    Object.entries(recipeData).forEach(([key, value]) => {
      if (key === 'image' && value) {
        formData.append('image', value);
      } else if (key !== 'id') {
        formData.append(key, value);
      }
    });

    const response = await apiClient.put(`/${recipeData.id}`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to update recipe');
  }
};
