import { useSelector } from 'react-redux';
import RecipeCard from '../components/RecipeCard';
import { Row, Col } from 'react-bootstrap';

export default function MyRecipes() {
  const { user } = useSelector(state => state.auth);
  const myRecipes = useSelector(state => 
    state.recipes.recipes.filter(r => r.userId === user?.id)
  );

  return (
    <div className="container mt-4">
      <h2>My Recipes</h2>
      <Row xs={1} md={2} lg={3} className="g-4">
        {myRecipes.map(recipe => (
          <Col key={recipe.id}>
            <RecipeCard recipe={recipe} />
          </Col>
        ))}
      </Row>
    </div>
  );
}
