import { useSelector } from 'react-redux';
import RecipeCard from '../components/RecipeCard';
import { Row, Col } from 'react-bootstrap';

export default function SavedRecipes() {
  const savedRecipes = useSelector(state => 
    state.recipes.recipes.filter(r => r.isSaved)
  );

  return (
    <div className="container mt-4">
      <h2>Saved Recipes</h2>
      <Row xs={1} md={2} lg={3} className="g-4">
        {savedRecipes.map(recipe => (
          <Col key={recipe.id}>
            {/* Add isSavedPage prop to indicate this is the Saved Recipes page */}
            <RecipeCard recipe={recipe} isSavedPage={true} />
          </Col>
        ))}
      </Row>
    </div>
  );
}