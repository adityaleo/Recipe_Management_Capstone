import { useDispatch } from 'react-redux';
import { addRecipeAsync } from '../store/slices/recipeSlice';
import RecipeForm from '../components/RecipeForm';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Alert } from 'react-bootstrap';

export default function CreateRecipe() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [error, setError] = useState(null);

  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      const resultAction = await dispatch(addRecipeAsync(values));
      if (addRecipeAsync.fulfilled.match(resultAction)) {
        navigate('/my'); // Redirect to user's recipes
      } else {
        setError('Failed to create recipe');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Create New Recipe</h2>
      {error && <Alert variant="danger">{error}</Alert>}
      <RecipeForm onSubmit={handleSubmit} />
    </div>
  );
}
