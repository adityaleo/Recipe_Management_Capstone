import { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchRecipesAsync } from '../store/slices/recipeSlice';
import RecipeCard from '../components/RecipeCard';
import { Row, Col, Form, InputGroup, Dropdown, Spinner, Alert } from 'react-bootstrap';
import { FiSearch } from 'react-icons/fi';

const CATEGORIES = ['All', 'Indian', 'Italian', 'Chinese', 'Mexican'];

export default function Home() {
  const dispatch = useDispatch();
  const { recipes, status, error } = useSelector(state => state.recipes);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    dispatch(fetchRecipesAsync());
  }, [dispatch]);

  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         recipe.ingredients.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || recipe.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (status === 'loading') return <Spinner animation="border" className="d-block mx-auto mt-4" />;
  if (status === 'failed') return <Alert variant="danger" className="mt-4">{error}</Alert>;

  return (
    <div className="container mt-4">
      {/* Search Bar with Category Filter Dropdown */}
      <div className="mb-5 d-flex align-items-center">
        <InputGroup className="search-bar flex-grow-1">
          <InputGroup.Text>
            <FiSearch size={20} />
          </InputGroup.Text>
          <Form.Control
            type="text"
            placeholder="Search recipes..."
            aria-label="Search recipes"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </InputGroup>
        <Dropdown className="ms-2">
          <Dropdown.Toggle variant="primary">
            {selectedCategory}
          </Dropdown.Toggle>
          <Dropdown.Menu>
            {CATEGORIES.map(category => (
              <Dropdown.Item
                key={category}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Dropdown.Item>
            ))}
          </Dropdown.Menu>
        </Dropdown>
      </div>

      {/* Recipe Cards */}
      <Row xs={1} md={2} lg={3} className="g-4">
        {filteredRecipes.length > 0 ? (
          filteredRecipes.map(recipe => (
            <Col key={recipe.id}>
              <RecipeCard recipe={recipe} />
            </Col>
          ))
        ) : (
          <div className="text-center w-100 mt-5">
            <h4>No recipes found matching your criteria</h4>
          </div>
        )}
      </Row>
    </div>
  );
}