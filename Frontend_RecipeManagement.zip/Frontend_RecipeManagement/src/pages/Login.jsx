import { useDispatch, useSelector } from 'react-redux';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { loginUser } from '../store/slices/authSlice';
import AuthForm from '../components/AuthForm';
import { Alert } from 'react-bootstrap';

export default function Login() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const { error } = useSelector(state => state.auth);

  // Get redirect path or default to home
  const from = location.state?.from?.pathname || '/';

  const handleSubmit = async (values) => {
    try {
      await dispatch(loginUser(values)).unwrap();
      navigate(from, { replace: true });
    } catch (err) {
      console.error('Login failed:', err);
    }
  };

  return (
    <div className="container mt-4" style={{ maxWidth: '400px' }}>
      <h2>Login</h2>
      {error && <Alert variant="danger">{error}</Alert>}
      <AuthForm type="login" onSubmit={handleSubmit} />
      <div className="mt-3 text-center">
        Don't have an account? <Link to="/register">Register here</Link>
      </div>
    </div>
  );
}
