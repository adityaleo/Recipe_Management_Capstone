import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaEdit } from 'react-icons/fa';
import { fetchRecipesAsync } from '../store/slices/recipeSlice';

export default function RecipeDetails() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const numericId = parseInt(id);
  const { user } = useSelector(state => state.auth);

  // Fetch fresh recipes when component mounts or ID changes
  useEffect(() => {
    dispatch(fetchRecipesAsync());
  }, [dispatch, numericId]);

  // Find recipe in both lists with proper ID type
  const recipe = useSelector(state => 
    state.recipes.recipes.find(r => r.id === numericId) ||
    state.recipes.savedRecipes.find(r => r.id === numericId)
  );

  // Add cache-buster to image URL
  const imageUrl = recipe?.imagePath 
    ? `http://localhost:5000/Images/${recipe.imagePath}?ts=${new Date().getTime()}`
    : '/placeholder.jpg';

  if (!recipe) return <Alert variant="danger">Recipe not found</Alert>;

  const isOwner = user?.id === recipe.userId;

  return (
    <div className="container mt-4">
      <h2>{recipe.title}</h2>
      <img 
        src={imageUrl} 
        alt={recipe.title} 
        className="img-fluid mb-3" 
        style={{ maxHeight: '400px', objectFit: 'cover' }}
      />
      <h4>Ingredients</h4>
      <p className="white-space-pre-wrap">{recipe.ingredients}</p>
      <h4>Instructions</h4>
      <p className="white-space-pre-wrap">{recipe.instructions}</p>
      
      {isOwner && (
        <Link to={`/edit-recipe/${recipe.id}`} className="btn btn-primary mt-3">
          <FaEdit className="me-2" />
          Edit Recipe
        </Link>
      )}
    </div>
  );
}