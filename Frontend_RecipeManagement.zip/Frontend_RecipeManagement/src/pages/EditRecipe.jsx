import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import RecipeForm from '../components/RecipeForm';
import { updateRecipeAsync } from '../store/slices/recipeSlice';
import { Alert } from 'react-bootstrap';

export default function EditRecipe() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const recipeId = parseInt(id);

  // Find recipe in both lists with proper ID type
  const recipe = useSelector(state => 
    state.recipes.recipes.find(r => r.id === recipeId) ||
    state.recipes.savedRecipes.find(r => r.id === recipeId)
  );

  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      const updateData = {
        ...values,
        id: recipeId,
        imagePath: recipe?.imagePath // Preserve existing image unless changed
      };
      
      await dispatch(updateRecipeAsync(updateData)).unwrap();
      
      // Force component refresh with cache busting
      navigate(`/recipe/${recipeId}?refresh=${Date.now()}`);
    } catch (err) {
      console.error('Update failed:', err);
    } finally {
      setSubmitting(false);
    }
  };

  if (!recipe) return <Alert variant="danger">Recipe not found</Alert>;

  // Prepare initial values with proper image URL
  const initialValues = {
    ...recipe,
    image: recipe.imagePath ? 
      `http://localhost:5000/Images/${recipe.imagePath}?${Date.now()}` : null
  };

  return (
    <div className="container mt-4">
      <h2>Edit Recipe</h2>
      <RecipeForm 
        onSubmit={handleSubmit}
        initialValues={initialValues}
        isEdit
      />
    </div>
  );
}