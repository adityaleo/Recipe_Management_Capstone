import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import CreateRecipe from './pages/CreateRecipe';
import SavedRecipes from './pages/SavedRecipes';
import RecipeDetails from './pages/RecipeDetails';
import { Provider } from 'react-redux';
import store from './store/store';
import MyRecipes from './pages/MyRecipes';
import EditRecipe from './pages/EditRecipe';
import Footer from './components/Footer';
import Login from './pages/Login';
import Register from './pages/Register';
import ProtectedRoute from './components/ProtectedRoute';

// Add the missing routes
function App() {
  return (
    <Provider store={store}>
      <Router>
        <Navigation />
        <div className="content-wrapper">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            
            <Route element={<ProtectedRoute />}>
              <Route path="/create" element={<CreateRecipe />} />
              <Route path="/my" element={<MyRecipes />} />
              <Route path="/edit-recipe/:id" element={<EditRecipe />} />
            </Route>
            
            <Route path="/" element={<Home />} />
            <Route path="/saved" element={<SavedRecipes />} />
            <Route path="/recipe/:id" element={<RecipeDetails />} />
          </Routes>
        </div>
        <Footer />
      </Router>
    </Provider>
  );
}

export default App;


