// src/components/ErrorBoundary.jsx (NEW)
import { Component } from 'react';
import { Alert } from 'react-bootstrap';

export default class ErrorBoundary extends Component {
  state = { error: null };
  
  static getDerivedStateFromError(error) {
    return { error };
  }

  render() {
    return this.state.error ? (
      <Alert variant="danger" className="m-3">
        <Alert.Heading>Application Error</Alert.Heading>
        <pre>{this.state.error.message}</pre>
      </Alert>
    ) : this.props.children;
  }
}

// Wrap App component
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <Provider store={store}>
        <App />
      </Provider>
    </ErrorBoundary>
  </React.StrictMode>
);