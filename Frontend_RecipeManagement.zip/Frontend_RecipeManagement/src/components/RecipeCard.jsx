import { useState } from 'react';
import { Card, Button } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import { 
  saveRecipeAsync, 
  deleteRecipeAsync 
} from '../store/slices/recipeSlice';
import { Link, useNavigate } from 'react-router-dom';
import { FaTrash, FaPenToSquare, FaBookmark, FaRegBookmark } from 'react-icons/fa6';

export default function RecipeCard({ recipe, isSavedPage }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector(state => state.auth);
  const [isSaved, setIsSaved] = useState(recipe.IsSaved);
  const [isProcessing, setIsProcessing] = useState(false);
  const isOwner = user?.id === recipe.userId;

  const handleSaveToggle = async () => {
    if (!user) return;
    
    setIsProcessing(true);
    try {
      const result = await dispatch(saveRecipeAsync(recipe.id)).unwrap();
      setIsSaved(result.IsSaved);
    } catch (err) {
      console.error('Failed to toggle save:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this recipe?')) {
      try {
        await dispatch(deleteRecipeAsync(recipe.id)).unwrap();
      } catch (err) {
        console.error('Failed to delete recipe:', err);
      }
    }
  };

  const imageUrl = recipe.imagePath 
    ? `http://localhost:5000/Images/${recipe.imagePath}`
    : '/placeholder.jpg';

  return (
    <Card className="recipe-card" style={{ width: '18rem', position: 'relative' }}>
      {/* Owner controls */}
      {isOwner && (
        <div className="owner-controls">
          <Button 
            variant="warning" 
            size="sm"
            onClick={() => navigate(`/edit-recipe/${recipe.id}`)}
            aria-label="Edit recipe"
          >
            <FaPenToSquare />
          </Button>
          
          <Button 
            variant="danger" 
            size="sm"
            onClick={handleDelete}
            aria-label="Delete recipe"
          >
            <FaTrash />
          </Button>
        </div>
      )}

      {/* Recipe image */}
      <Card.Img
        variant="top"
        src={imageUrl}
        alt={recipe.title}
        className="recipe-image"
      />

      {/* Card body */}
      <Card.Body>
        <Card.Title className="recipe-title">{recipe.title}</Card.Title>
        
        <Card.Text className="recipe-preview">
          {recipe.ingredients?.substring(0, 100).replace(/\n/g, ' ') || 'No ingredients listed'}
        </Card.Text>

        <div className="card-actions">
          <Button 
            variant={isSavedPage ? 'danger' : (isSaved ? 'warning' : 'primary')}
            onClick={handleSaveToggle}
            disabled={isProcessing || !user}
            aria-label={isSavedPage ? 'Remove from saved' : (isSaved ? 'Unsave recipe' : 'Save recipe')}
          >
            {isProcessing ? (
              <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" />
            ) : isSavedPage ? (
              <><FaTrash /> Remove</>
            ) : isSaved ? (
              <><FaBookmark /> Unsave</>
            ) : (
              <><FaRegBookmark /> Save</>
            )}
          </Button>

          <Link 
            to={`/recipe/${recipe.id}`} 
            className="btn btn-secondary"
            aria-label="View recipe details"
          >
            Read More
          </Link>
        </div>
      </Card.Body>

      <style jsx>{`
        .recipe-card {
          transition: transform 0.2s;
          margin-bottom: 1.5rem;
          border: 1px solid #e0e0e0;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .recipe-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .owner-controls {
          position: absolute;
          top: 10px;
          right: 10px;
          display: flex;
          gap: 8px;
          z-index: 2;
        }
        
        .recipe-image {
          height: 220px;
          object-fit: cover;
          border-radius: 12px 12px 0 0;
        }
        
        .recipe-title {
          font-size: 1.3rem;
          font-weight: 600;
          margin-bottom: 0.8rem;
          color: #2d3436;
        }
        
        .recipe-preview {
          color: #636e72;
          min-height: 60px;
          margin-bottom: 1.2rem;
          font-size: 0.95rem;
          line-height: 1.4;
        }
        
        .card-actions {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 0.8rem;
        }

        /* Button styles */
        .btn-danger {
          background-color: #ff7675;
          border-color: #ff7675;
          color: white;
          font-weight: 500;
          padding: 8px 16px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.2s;
        }

        .btn-danger:hover {
          background-color: #ff5252;
          border-color: #ff5252;
          transform: translateY(-1px);
        }

        .btn-warning {
          background-color: #ffeaa7;
          border-color: #ffeaa7;
          color: #2d3436;
          font-weight: 500;
          padding: 8px 16px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .btn-primary {
          background-color: #74b9ff;
          border-color: #74b9ff;
          color: white;
          font-weight: 500;
          padding: 8px 16px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.2s;
        }

        .btn-primary:hover {
          background-color: #0984e3;
          border-color: #0984e3;
          transform: translateY(-1px);
        }

        .btn-secondary {
          background-color: #636e72;
          border-color: #636e72;
          color: white;
          padding: 8px 16px;
          border-radius: 8px;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .btn-secondary:hover {
          background-color: #2d3436;
          border-color: #2d3436;
          color: white;
          transform: translateY(-1px);
        }

        @media (max-width: 768px) {
          .recipe-card {
            width: 100% !important;
          }
          
          .card-actions {
            flex-direction: column;
          }
          
          .btn {
            width: 100%;
            justify-content: center;
          }
        }
      `}</style>
    </Card>
  );
}