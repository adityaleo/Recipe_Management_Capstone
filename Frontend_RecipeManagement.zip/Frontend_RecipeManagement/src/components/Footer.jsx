import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { FaLinkedin, FaGithub, FaEnvelope, FaPhoneAlt, FaInstagram, FaFacebook, FaTwitter } from 'react-icons/fa';

export default function Footer() {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [email, setEmail] = useState('');

  const handleSubscribe = () => {
    if (email) {
      setIsSubscribed(true);
      setTimeout(() => {
        setIsSubscribed(false);
      }, 6000);
    }
  };

  return (
    <footer className="footer py-2 bg-dark text-light" style={{ marginTop: 'auto' }}>
      <Container>
        <Row className="g-2">
          <Col md={3} className="mb-1">
            <h5 className="mb-1" style={{ fontSize: '0.95rem' }}>Follow Us</h5>
            <div className="d-flex gap-1">
              <a href="https://facebook.com/recipehub" target="_blank" rel="noopener noreferrer" className="text-light">
                <FaFacebook size={18} />
              </a>
              <a href="https://twitter.com/recipehub" target="_blank" rel="noopener noreferrer" className="text-light">
                <FaTwitter size={18} />
              </a>
              <a href="https://instagram.com/recipehub" target="_blank" rel="noopener noreferrer" className="text-light">
                <FaInstagram size={18} />
              </a>
            </div>
          </Col>

          <Col md={3} className="mb-1">
            <h5 className="mb-1" style={{ fontSize: '0.95rem' }}>Quick Links</h5>
            <ul className="list-unstyled">
              <li><Link to="/" className="text-decoration-none text-light" style={{ fontSize: '0.85rem' }}>Home</Link></li>
              <li><Link to="/create" className="text-decoration-none text-light" style={{ fontSize: '0.85rem' }}>Create Recipe</Link></li>
              <li><Link to="/saved" className="text-decoration-none text-light" style={{ fontSize: '0.85rem' }}>Saved Recipes</Link></li>
              <li><Link to="/my" className="text-decoration-none text-light" style={{ fontSize: '0.85rem' }}>My Recipes</Link></li>
            </ul>
          </Col>

          <Col md={3} className="mb-1">
            <h5 className="mb-1" style={{ fontSize: '0.95rem' }}>Subscribe</h5>
            <Form>
              <Form.Control 
                type="email" 
                placeholder="Enter your email" 
                className="mb-1"
                style={{ fontSize: '0.85rem' }}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <Button 
                variant={isSubscribed ? 'success' : 'primary'}
                size="sm" 
                className="w-100" 
                style={{ fontSize: '0.85rem' }}
                onClick={handleSubscribe}
                disabled={isSubscribed}
              >
                {isSubscribed ? 'Subscribed' : 'Subscribe'}
              </Button>
            </Form>
          </Col>

          <Col md={3} className="mb-1">
            <h5 className="mb-1" style={{ fontSize: '0.95rem' }}>Contact Us</h5>
            <ul className="list-unstyled">
              <li className="mb-1">
                <FaEnvelope className="me-1" />
                <a href="mailto:support@recipehub.com" className="text-decoration-none text-light" style={{ fontSize: '0.85rem' }}>
                  support@recipehub.com
                </a>
              </li>
              <li className="mb-1">
                <FaPhoneAlt className="me-1" />
                <span style={{ fontSize: '0.85rem' }}>+1 (555) 123-4567</span>
              </li>
              <li className="mb-1">
                <FaLinkedin className="me-1" />
                <a 
                  href="https://linkedin.com/company/recipehub" 
                  className="text-decoration-none text-light"
                  target="_blank" 
                  rel="noopener noreferrer"
                  style={{ fontSize: '0.85rem' }}
                >
                  LinkedIn Profile
                </a>
              </li>
              <li>
                <FaGithub className="me-1" />
                <a 
                  href="https://github.com/recipehub" 
                  className="text-decoration-none text-light"
                  target="_blank" 
                  rel="noopener noreferrer"
                  style={{ fontSize: '0.85rem' }}
                >
                  GitHub Repository
                </a>
              </li>
            </ul>
          </Col>
        </Row>
        
        <Row>
          <Col className="text-center pt-1 border-top border-secondary">
            <p className="mb-0 text-muted" style={{ fontSize: '0.8rem' }}>
              © {new Date().getFullYear()} Recipe Hub. All rights reserved.
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}