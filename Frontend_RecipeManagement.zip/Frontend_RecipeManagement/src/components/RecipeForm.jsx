import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { Button, Alert } from 'react-bootstrap';

const validationSchema = Yup.object().shape({
  title: Yup.string().required('Required'),
  category: Yup.string().required('Required'),
  ingredients: Yup.string().required('Required'),
  instructions: Yup.string().required('Required'),
});

export default function RecipeForm({ initialValues, onSubmit, isEdit }) {
  return (
    <Formik
      initialValues={initialValues || {
        title: '',
        category: '',
        ingredients: '',
        instructions: '',
        image: null
      }}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {({ values, setFieldValue }) => (
        <Form>
          {/* Image Preview */}
          {isEdit && values.image && (
            <div className="mb-3">
              <img 
                src={values.image} 
                alt="Current recipe" 
                style={{ maxWidth: '200px' }}
                className="img-thumbnail d-block mb-2"
              />
            </div>
          )}

          {/* Title Field */}
          <div className="mb-3">
            <label>Title</label>
            <Field name="title" className="form-control" />
            <ErrorMessage name="title" component={Alert} variant="danger" />
          </div>

          {/* Category Field */}
          <div className="mb-3">
            <label>Category</label>
            <Field as="select" name="category" className="form-select">
              <option value="">Select Category</option>
              <option value="Indian">Indian</option>
              <option value="Italian">Italian</option>
              <option value="Chinese">Chinese</option>
              <option value="Mexican">Mexican</option>
            </Field>
            <ErrorMessage name="category" component={Alert} variant="danger" />
          </div>

          {/* Ingredients Field */}
          <div className="mb-3">
            <label>Ingredients</label>
            <Field 
              as="textarea" 
              name="ingredients" 
              className="form-control" 
              rows="3" 
            />
            <ErrorMessage name="ingredients" component={Alert} variant="danger" />
          </div>

          {/* Instructions Field */}
          <div className="mb-3">
            <label>Instructions</label>
            <Field 
              as="textarea" 
              name="instructions" 
              className="form-control" 
              rows="5" 
            />
            <ErrorMessage name="instructions" component={Alert} variant="danger" />
          </div>

          {/* Image Upload Field */}
          <div className="mb-4">
            <label className="d-block">{isEdit ? 'Change Image' : 'Upload Image'}</label>
            <input 
              type="file" 
              onChange={(e) => setFieldValue('image', e.target.files[0])}
              accept="image/*"
            />
          </div>

          {/* Submit Button */}
          <Button type="submit" variant="primary" className="w-100">
            {isEdit ? 'Update Recipe' : 'Create Recipe'}
          </Button>
        </Form>
      )}
    </Formik>
  );
}