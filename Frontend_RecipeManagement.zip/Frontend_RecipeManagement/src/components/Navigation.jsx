import { Link } from 'react-router-dom';
import { Navbar, Container, Nav, Button } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import { logoutUser } from '../store/slices/authSlice';

export default function Navigation() {
  const { user } = useSelector(state => state.auth);
  const dispatch = useDispatch();

  const handleLogout = () => {
    dispatch(logoutUser());
  };

  return (
    <Navbar bg="light" expand="lg" className="position-relative">
      <Container>
        <Navbar.Brand as={Link} to="/">Recipe Management</Navbar.Brand>

        {/* Moving Text Container */}
        {!user && (
          <div style={{
            position: 'absolute',
            left: '50%',
            transform: 'translateX(-50%)',
            width: '300px',
            overflow: 'hidden',
            whiteSpace: 'nowrap'
          }}>
            <div style={{
              animation: 'marquee 10s linear infinite',
              display: 'inline-block',
              paddingLeft: '100%'
            }}>
              Welcome to Recipe Management Project
            </div>
          </div>
        )}

        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/">Home</Nav.Link>
            {user && (
              <>
                <Nav.Link as={Link} to="/create">Create Recipe</Nav.Link>
                <Nav.Link as={Link} to="/my">My Recipes</Nav.Link>
                <Nav.Link as={Link} to="/saved">Saved Recipes</Nav.Link>
              </>
            )}
          </Nav>
          <Nav>
            {user ? (
              <Button variant="outline-danger" onClick={handleLogout} className="ms-2">
                Logout
              </Button>
            ) : (
              <>
                <Nav.Link as={Link} to="/login" className="ms-2">Login</Nav.Link>
                <Nav.Link as={Link} to="/register" className="ms-2">Register</Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>

        {/* Animation Styles */}
        <style>
          {`
            @keyframes marquee {
              0% { transform: translateX(0); }
              100% { transform: translateX(-100%); }
            }
            @media (max-width: 768px) {
              .mobile-hide-marquee {
                display: none !important;
              }
            }
          `}
        </style>
      </Container>
    </Navbar>
  );
}