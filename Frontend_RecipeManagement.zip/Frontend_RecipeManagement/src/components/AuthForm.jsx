import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { Alert, Button } from 'react-bootstrap';

const AuthSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('Required'),
  password: Yup.string().required('Required').min(6, 'Too short!'),
});

export default function AuthForm({ type, onSubmit }) {
  return (
    <Formik
      initialValues={{ email: '', password: '' }}
      validationSchema={AuthSchema}
      onSubmit={onSubmit}
    >
      {({ isSubmitting }) => (
        <Form className="auth-form">
          <div className="mb-3">
            <label>Email</label>
            <Field name="email" type="email" className="form-control" />
            <ErrorMessage name="email" component={Alert} variant="danger" />
          </div>

          <div className="mb-3">
            <label>Password</label>
            <Field name="password" type="password" className="form-control" />
            <ErrorMessage name="password" component={Alert} variant="danger" />
          </div>

          <Button 
            type="submit" 
            variant="primary" 
            className="w-100"
            disabled={isSubmitting}
          >
            {type === 'login' ? 'Login' : 'Register'}
          </Button>
        </Form>
      )}
    </Formik>
  );
}