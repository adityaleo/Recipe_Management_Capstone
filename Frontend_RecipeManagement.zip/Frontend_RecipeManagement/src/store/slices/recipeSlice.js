
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'; //  Creating a Redux slice (reducers + actions)
import { 
  fetchRecipes, 
  createRecipe, 
  saveRecipeAPI, 
  deleteRecipeAPI,
  updateRecipeAPI 
} from '../../services/recipeService';

// Async thunks
export const fetchRecipesAsync = createAsyncThunk(       //Handles async operations like API calls.

  'recipes/fetchRecipes',
  async (_, { rejectWithValue }) => {
    try {
      return await fetchRecipes();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const addRecipeAsync = createAsyncThunk(
  'recipes/addRecipe',
  async (recipeData, { rejectWithValue }) => {
    try {
      return await createRecipe(recipeData);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const saveRecipeAsync = createAsyncThunk(
  'recipes/saveRecipe',
  async (recipeId, { rejectWithValue }) => {
    try {
      return await saveRecipeAPI(recipeId);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const deleteRecipeAsync = createAsyncThunk(
  'recipes/deleteRecipe',
  async (recipeId, { rejectWithValue }) => {
    try {
      await deleteRecipeAPI(recipeId);
      return recipeId;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const updateRecipeAsync = createAsyncThunk(
  'recipes/updateRecipe',
  async (updatedRecipe, { rejectWithValue }) => {
    try {
      return await updateRecipeAPI(updatedRecipe);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const initialState = {
  recipes: [],
  savedRecipes: [],
  status: 'idle',
  error: null
};

const recipeSlice = createSlice({
  name: 'recipes',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchRecipesAsync.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchRecipesAsync.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.recipes = action.payload;
      })
      .addCase(fetchRecipesAsync.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      .addCase(addRecipeAsync.fulfilled, (state, action) => {
        state.recipes.push(action.payload);
      })
      .addCase(saveRecipeAsync.fulfilled, (state, action) => {
        // Update main recipes list
        const recipeIndex = state.recipes.findIndex(r => r.id === action.payload.id);
        if (recipeIndex >= 0) {
          state.recipes[recipeIndex] = action.payload;
        }
        
        // Update savedRecipes list
        if (action.payload.IsSaved) {
          const exists = state.savedRecipes.some(r => r.id === action.payload.id);
          if (!exists) {
            state.savedRecipes.push(action.payload);
          }
        } else {
          state.savedRecipes = state.savedRecipes.filter(r => r.id !== action.payload.id);
        }
      })
      .addCase(deleteRecipeAsync.fulfilled, (state, action) => {
        state.recipes = state.recipes.filter(recipe => recipe.id !== action.payload);
        state.savedRecipes = state.savedRecipes.filter(recipe => recipe.id !== action.payload);
      })
      .addCase(updateRecipeAsync.fulfilled, (state, action) => {
        const index = state.recipes.findIndex(r => r.id === action.payload.id);
        if (index >= 0) state.recipes[index] = action.payload;
        const savedIndex = state.savedRecipes.findIndex(r => r.id === action.payload.id);
        if (savedIndex >= 0) state.savedRecipes[savedIndex] = action.payload;
      });
  }
});

export default recipeSlice.reducer;