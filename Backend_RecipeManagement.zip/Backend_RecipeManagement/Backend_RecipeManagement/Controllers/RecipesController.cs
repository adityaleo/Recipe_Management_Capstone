﻿using Microsoft.AspNetCore.Mvc;
using Backend_RecipeManagement.Data;
using Backend_RecipeManagement.Models;
using Microsoft.EntityFrameworkCore;
using Backend_RecipeManagement.Models.DTO;
using System.Security.Claims;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authorization;

namespace Backend_RecipeManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RecipesController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public RecipesController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (int.TryParse(userIdClaim, out var userId))
            {
                return userId;
            }
            return null;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Recipe>>> GetRecipes()
        {
            return await _context.Recipes
                .Include(r => r.User)
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Recipe>> GetRecipe(int id)
        {
            var recipe = await _context.Recipes
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.Id == id);

            return recipe == null ? NotFound() : recipe;
        }

        [Authorize]
        [HttpPost]
        public async Task<ActionResult<Recipe>> CreateRecipe([FromForm] RecipeCreateDto recipeDto)
        {
            var userId = GetCurrentUserId();
            if (!userId.HasValue) return Unauthorized();

            var recipe = new Recipe
            {
                Title = recipeDto.Title,
                Category = recipeDto.Category,
                Ingredients = recipeDto.Ingredients,
                Instructions = recipeDto.Instructions,
                UserId = userId.Value
            };

            if (recipeDto.Image != null)
                recipe.ImagePath = await SaveImage(recipeDto.Image);

            _context.Recipes.Add(recipe);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetRecipe), new { id = recipe.Id }, recipe);
        }

        [Authorize]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRecipe(int id, [FromForm] RecipeUpdateDto recipeDto)
        {
            var userId = GetCurrentUserId();
            if (!userId.HasValue) return Unauthorized();

            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe == null) return NotFound();
            if (recipe.UserId != userId.Value) return Forbid();

            recipe.Title = recipeDto.Title;
            recipe.Category = recipeDto.Category;
            recipe.Ingredients = recipeDto.Ingredients;
            recipe.Instructions = recipeDto.Instructions;
            recipe.UpdatedAt = DateTime.UtcNow;

            if (recipeDto.Image != null)
            {
                if (!string.IsNullOrEmpty(recipe.ImagePath))
                    DeleteImage(recipe.ImagePath);
                recipe.ImagePath = await SaveImage(recipeDto.Image);
            }

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [Authorize]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRecipe(int id)
        {
            var userId = GetCurrentUserId();
            if (!userId.HasValue) return Unauthorized();

            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe == null) return NotFound();
            if (recipe.UserId != userId.Value) return Forbid();

            if (!string.IsNullOrEmpty(recipe.ImagePath))
                DeleteImage(recipe.ImagePath);

            _context.Recipes.Remove(recipe);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [Authorize]
        [HttpPost("{id}/save")]
        public async Task<IActionResult> SaveRecipe(int id)
        {
            try
            {
                var recipe = await _context.Recipes.FindAsync(id);
                if (recipe == null) return NotFound();

                recipe.IsSaved = !recipe.IsSaved; // Toggle save status
                await _context.SaveChangesAsync();

                return Ok(recipe);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error saving recipe");
            }
        }

        private async Task<string> SaveImage(IFormFile image)
        {
            var uploadsPath = Path.Combine(_env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"), "Images");
            if (!Directory.Exists(uploadsPath))
            {
                Directory.CreateDirectory(uploadsPath);
            }

            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(image.FileName);
            var filePath = Path.Combine(uploadsPath, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await image.CopyToAsync(stream);
            }

            return fileName;
        }

        private void DeleteImage(string fileName)
        {
            var filePath = Path.Combine(_env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"), "Images", fileName);
            if (System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
            }
        }
    }
}

