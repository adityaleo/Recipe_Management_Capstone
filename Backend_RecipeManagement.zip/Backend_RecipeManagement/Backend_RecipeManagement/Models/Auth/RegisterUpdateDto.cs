﻿using System.ComponentModel.DataAnnotations;

namespace Backend_RecipeManagement.Models.Auth
{
    public class RegisterDto
    {
        [Required, EmailAddress]
        public string Email { get; set; } = null!;

        [Required, StringLength(100, MinimumLength = 6)]
        public string Password { get; set; } = null!;
    }
}