﻿using System.ComponentModel.DataAnnotations;

namespace Backend_RecipeManagement.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; } = null!;

        [Required]
        public string PasswordHash { get; set; } = null!;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public List<Recipe> Recipes { get; set; } = new List<Recipe>();
    }
}