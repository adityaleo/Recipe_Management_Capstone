﻿using Microsoft.AspNetCore.Http;

namespace Backend_RecipeManagement.Models.DTO
{
    public class RecipeUpdateDto
    {
        public string Title { get; set; }
        public string Category { get; set; }
        public string Ingredients { get; set; }
        public string Instructions { get; set; }
        public IFormFile? Image { get; set; }
    }
}
