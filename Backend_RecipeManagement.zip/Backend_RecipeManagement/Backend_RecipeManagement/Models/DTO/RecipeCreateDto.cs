﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace Backend_RecipeManagement.Models.DTO
{
    public class RecipeCreateDto
    {
        [Required]
        public string Title { get; set; } = null!;

        [Required]
        public string Category { get; set; } = null!;

        [Required]
        public string Ingredients { get; set; } = null!;

        [Required]
        public string Instructions { get; set; } = null!;

        public IFormFile? Image { get; set; }
    }
}