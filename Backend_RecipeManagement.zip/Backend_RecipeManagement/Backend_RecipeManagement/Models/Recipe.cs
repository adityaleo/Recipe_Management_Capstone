﻿using System.ComponentModel.DataAnnotations;

namespace Backend_RecipeManagement.Models
{
    public class Recipe
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Category { get; set; }

        [Required]
        public string Ingredients { get; set; }

        [Required]
        public string Instructions { get; set; }

        public string? ImagePath { get; set; }
        public bool IsSaved { get; set; } = false;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        // Ownership properties
        public int UserId { get; set; }
        public User? User { get; set; }
    }
}

