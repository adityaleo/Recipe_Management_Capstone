﻿using System.ComponentModel.DataAnnotations;

namespace Backend_RecipeManagement.Models
{
    public class UserSavedRecipe
    {
        [Required]
        public int UserId { get; set; }

        [Required]
        public int RecipeId { get; set; }

        public DateTime SavedAt { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public User User { get; set; } = null!;
        public Recipe Recipe { get; set; } = null!;
    }
}